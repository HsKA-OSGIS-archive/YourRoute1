function changeRoutertoBRouter() {
	var router1 = document.querySelector("#iFrameBRouter");
		router1.style.display = "block";	
	var router2 = document.querySelector("#iFrameORS");
		router2.style.display = "none";
}

function changeRoutertoORS() {
	var router1 = document.querySelector("#iFrameBRouter");
		router1.style.display = "none";	
	var router2 = document.querySelector("#iFrameORS");
		router2.style.display = "block";
}
